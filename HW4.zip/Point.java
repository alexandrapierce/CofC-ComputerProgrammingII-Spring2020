
/**
 * Point Class: creates a point given a value for x & y
  *Alex Pierce
 * CSCI 221 HW 4
 */
public class Point
{
    private int x;
    private int y;
    private Point p;
    
  /* No parameters. In this no argument constructor initialize the x and y 
   instance variables to 0 */
   public Point() {
        this.x = 0;
        this.y = 0;
  }
  /* In this overloaded constructor use the provided point object’s x and y instance
    variable values to initialize this new point object’s x and y instances variable values.*/
   public Point(Point point) {
        if (point != null) {
            if (point.getX() >= 0 && point.getX() <= GridConstants.MAX_PANEL_WIDTH) {
                this.x = point.getX();
            }
            else { 
                this.x = 0;
            }
            if (point.getY() >= 0 && point.getY() <= GridConstants.MAX_PANEL_HEIGHT) {
                this.y = point.getY();
            }
            else { 
                this.y = 0;
            }
        }
  }
  /*In this overloaded constructor use the provided x and y primitive values to 
   initialize the x and y instance variable values. */
   public Point(int x, int y) {
    if (x>= 0 && x<= GridConstants.MAX_PANEL_WIDTH) {
        this.x = x;
    }
    else {
        this.x = 0;
    }
    if (y>= 0 && y<= GridConstants.MAX_PANEL_HEIGHT) {
        this.y = y;
    }
    else {
        this.y = 0;
    }
  }
  //Get the x coordinate instance variable.
  public int getX() {
        return x;
  }
  //Get the y coordinate instance variable.
  public int getY() {
        return y;
  }
  //Set the x coordinate value.
  public void setX (int x) {
        this.x = x;
  }
  //Set the y coordinate value. 
  public void setY (int y) {
        this.y = y;
  }
  //Set to an existing point object.
  public void setPoint (Point p) {
      if (p != null) {
            x = p.getX();
            y = p.getY();
            p.setX(x);
            p.setY(y);
        }
  }
  public String toString() {
        return ("(" + x + "," + y + ")"); 
  }
  public static void main (String[] args)
  { 
      Point pt1 = new Point();
      System.out.println(pt1);
      Point pt2 = new Point(4,6);
      System.out.println(pt2);
  }
}