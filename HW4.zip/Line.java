
/**
 *Line Class: Creates lines with given points.
 *Alex Pierce
 *CSCI 221 - HW 4
 */
public class Line
{
    // instance variables - replace the example below with your own
    private Point start;
    private Point end;
    /**
     * Constructor for objects of class Line
     */
    public Line()
    {
        // initialise instance variables
        this.start = null;
        this.end = null;
    }
    public Line (Point start, Point end) 
    {
        if (start != null && end != null) {
            this.start = start;
            this.end = end;
        }
    }
    //returns point object
    public Point getStart() {
        return this.start;
    }
    //returns point object
    public Point getEnd() {
        return this.end;
    }
    //set start point instance variable- start
    public void setStart(Point start){
        if (start != null) {
            getStart().setPoint(start);
    }
    }
    //set start point instance variable- end
    public void setEnd(Point end) {
       if (end != null) {
            getEnd().setPoint(end);
    } 
    }
    //evaluates if the start and end instance variables are valid 
    public boolean isValid() {
        if (start != null && end != null) {
            return true;
        }
        else {
            return false;
        }
    }
    public static void main (String[] args) { 
      Point pt1 = new Point(1,2);
      Point pt2 = new Point(0,1);
      Line line = new Line (pt1, pt2);
      System.out.println(line);
    }
}
