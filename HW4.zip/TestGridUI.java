
/**
 * CSCI 221 Spring 2020
 * HW 4, part 3
 * Alex Pierce 
 *
 */
public class TestGridUI { 
public static void main(String[] args) {
    GridUI gridA = new GridUI();
    GridUI gridB = new GridUI();
    GridUI gridC = new GridUI();
    
    int i;
    
    //gridA vertical lines
    for (i=0; i <= GridConstants.MAX_PANEL_WIDTH; i++) {
        Point p1V = new Point (i,0);
        Point p2V = new Point (i,400);
        Line vLine = new Line (p1V, p2V);
        gridA.addLine(vLine);
        i += 200;
    }
    //gridA horizontal lines
    for (i=0; i <= GridConstants.MAX_PANEL_HEIGHT; i++) {
        Point p1H = new Point (0,i);
        Point p2H = new Point (400, i);
        Line hLine = new Line (p1H, p2H);
        gridA.addLine(hLine);
        i += 200;
    }    
    //gridB vertical lines
    for (i=0; i <= GridConstants.MAX_PANEL_WIDTH; i++) {
        Point p1V = new Point (i,0);
        Point p2V = new Point (i,400);
        Line vLine = new Line (p1V, p2V);
        gridB.addLine(vLine);
        i += 100;
    }
    //gridB horizontal lines
    for (i=0; i <= GridConstants.MAX_PANEL_HEIGHT; i++) {
        Point p1H = new Point (0,i);
        Point p2H = new Point (400, i);
        Line hLine = new Line (p1H, p2H);
        gridB.addLine(hLine);
        i += 100;
    }    
    //gridC vertical lines
    for (i=0; i <= GridConstants.MAX_PANEL_WIDTH; i++) {
        Point p1V = new Point (i,0);
        Point p2V = new Point (i,400);
        Line vLine = new Line (p1V, p2V);
        gridC.addLine(vLine);
        i += 50;
    }
    //gridC horizontal lines
    for (i=0; i <= GridConstants.MAX_PANEL_HEIGHT; i++) {
        Point p1H = new Point (0,i);
        Point p2H = new Point (400, i);
        Line hLine = new Line (p1H, p2H);
        gridC.addLine(hLine);
        i += 50;
    }    
} 
}