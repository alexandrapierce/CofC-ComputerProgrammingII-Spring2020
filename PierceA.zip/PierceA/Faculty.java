package HW7;
/**
 * Faculty class
 * Alex Pierce
 * CSCI 221- HW 7
 * This code is my own work
 * This class extends employee, providing a department to each faculty member
 */
public class Faculty extends Employee
{
    //initialize instance variable- each faculty has a department
    private String department;
    //constructor that allows one to send value for instance, grabs name and employeeNumber from employee class
    public Faculty(String name, int employeeNumber, String department) {
        super(name, employeeNumber);
        this.department = department;
    }
    //method that writes output, overrides super class
    @Override
    public void writeOutput() {
        super.writeOutput();
        System.out.println("Faculty Department: " + this.department);
    }
    //method that tests if two faculty members are equal
    public boolean equals(Faculty otherFaculty) {
        return (super.equals(otherFaculty) && (this.department.equals(otherFaculty.department)));
    }
}