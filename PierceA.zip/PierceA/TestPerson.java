package HW7;
/**
 * Test Person class
 * Alex Pierce
 * CSCI 221- HW 7
 * This code is my own work
 * This is a test class
 */
public class TestPerson
{
    public TestPerson() {
        Person p1 = new Person ("Sam Spade");
        Person p2 = new Faculty ("Sebastian Van Delden",11000,"Computer Science");
        Person p3 = new Faculty ("Sebastian Van Delden", 23000, "Sociology");
        Person p4 = new Faculty ("Vince Lombardi", 90000, "Sociology");
        Person p5 = new Faculty ("Vince Lombardi", 90000, "Sociology");
        Person p6 = new Staff ("Marilee Smith",11111, 4);
        p1.writeOutput();
        System.out.println();
        p2.writeOutput();
        System.out.println();
        p3.writeOutput();
        System.out.println();
        p4.writeOutput();
        System.out.println();
        p5.writeOutput();
        System.out.println();
        p6.writeOutput();
        System.out.println();
        System.out.println(p2.equals(p3));
        System.out.println(p4.equals(p5));
        System.out.println(p4 == p5);
        System.out.println("Sam Spade".equals(p2));
        System.out.println("Sam Spade".equals(p6));
    }
}
