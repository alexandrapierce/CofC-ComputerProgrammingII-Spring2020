package HW7;
/**
 * Employee class 
 * Alex Pierce
 * CSCI 221- HW 7
 * This code is my own work
 * This class extends Person, providing an employee number to each employee
 */
public class Employee extends Person
{
    //initialize instance variable- each employee has employeeNumber
    private int employeeNumber;
    //constructor that allows one to send value for instance, grabs name from person class
    public Employee(String name, int employeeNumber) {
        super(name);
        this.employeeNumber = employeeNumber;
    }
    //method that writes output, overrides super class
    @Override
    public void writeOutput() {
        super.writeOutput();
        System.out.println("Employee Number: " + this.employeeNumber);
    }
    //method that tests if two employees are equal
    public boolean equals(Employee otherEmployee) {
        return (this.hasSameName(otherEmployee) && (this.employeeNumber == otherEmployee.employeeNumber));
    }
    
}
