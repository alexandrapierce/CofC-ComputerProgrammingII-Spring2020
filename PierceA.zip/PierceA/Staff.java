package HW7;
/**
 * Staff class
 * Alex Pierce
 * CSCI 221- HW 7
 * This code is my own work
 * This class also extends employee providing each staff worker with a number of years on staff
 */
public class Staff extends Employee
{
    //initialize instance variable- each staff member has numYears worked
    private int yearsWorked;
    //constructor that allows one to send value for instance, grabs name and employeeNumber from employee class
    public Staff(String name, int employeeNumber, int numYears) {
        super(name, employeeNumber);
        this.yearsWorked = numYears;
    }
    //method that writes output, overrides super class
    @Override
    public void writeOutput() {
        super.writeOutput();
        System.out.println("Number of years on Staff: " + this.yearsWorked);
    }
    //method that tests if two staff members are equal
    public boolean equals(Staff otherStaff) {
        return (super.equals(otherStaff) && (this.yearsWorked == otherStaff.yearsWorked));
    }
}
